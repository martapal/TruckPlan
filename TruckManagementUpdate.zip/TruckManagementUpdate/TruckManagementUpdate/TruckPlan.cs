﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Device.Location;


namespace TruckManagementUpdate
{
    class TruckPlan
    {
        private int TruckPlanID { get; set; }
        private int DriverID { get; set; }
        private int TruckID { get; set; }
      
        private GeoCoordinate StartingPoint { get; set; }

        private GeoCoordinate Destination { get; set; }

        private DateTime Date { get; set; }

        private IEnumerable<String> Countries;

        
       


     
    protected internal double TotalDistance(GeoCoordinate StartingPoint, GeoCoordinate Destination)
        {
            
            double distance = StartingPoint.GetDistanceTo(Destination);
        return distance;
    }


    /*
    var KilommetersSum = TruckPlan.Where(d => d.Age > 50)
                                  .select(d => d)
                                   .where(GPS => GPS.reverseGecod = Germany)
                                    .select(GPS => GPS)
                                    .where(TruckPlan.time = february 2018)

    */
    }

}
