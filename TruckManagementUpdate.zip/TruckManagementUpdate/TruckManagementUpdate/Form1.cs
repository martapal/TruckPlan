﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http;
using System.Net.Http.Headers;
//using Windows.Services.Maps;
//using Windows.Devices.Geolocation;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Device.Location;


namespace TruckManagementUpdate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //private Truck truckObj;


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
       
        private const string URL = "http://api.positionstack.com/v1/reverse";
        //private string urlParameters = "?access_key=4cb628f6f956689a0fffd2d321b408a3&query=40.7638435,-73.9729691";
        private string urlParameters = "?access_key=4cb628f6f956689a0fffd2d321b408a3&query=" + lat + "," + longi;        
        
        // static double lat = 40.7638435;
        static double lat = 40.7638435;//truck.latitude
        static double longi = -73.9729691;//truck. longitude
        private void button3_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));
            
            // List data response.
            HttpResponseMessage response = client.GetAsync(URL + urlParameters).Result; 
            if (response.IsSuccessStatusCode)
            {
                // Parse the response body.
                var dataObjects = response.Content.ReadAsStringAsync().Result;
                JObject json = JObject.Parse(dataObjects);
                dynamic jsonde = JsonConvert.DeserializeObject(dataObjects);
                string TextResult = jsonde.data[0].country.Value;
                textBox1.Text = TextResult;
                Console.WriteLine(TextResult);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }

            // Make any other calls using HttpClient here.
            client.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var truck = new TruckPlan();
            var sCoord = new GeoCoordinate(40.7638435, -73.9729691);//TruckPlan.StartingPoint
            var eCoord = new GeoCoordinate(51.5074, 0.1278);//TruckPlan.Destination
            double result = truck.TotalDistance(sCoord, eCoord);
            textBox2.Text = result.ToString();
            Console.WriteLine(result);
        }
    }
}

