﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TruckManagementUpdate
{
    class Truck

    {
        private int TruckID { get; set; }
        private string TruckType { get; set; }

        private int weight { get; set; }

        private int Length { get; set; }

        private string LicensePlate { get; set; }

        protected double latitude { get; set; }

        private double longitude { get; set; }

        Truck()
        {

        }
    }
    
  
}
