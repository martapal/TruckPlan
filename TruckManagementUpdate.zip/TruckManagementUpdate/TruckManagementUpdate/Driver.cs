﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TruckManagementUpdate
{
    class Driver
    {

        private int DriverID { get; set; }
        private string FirstName { get; set; }
        private string LastName { get; set; }
        private string Adress { get; set; }
        private string LicenseNO { get; set; }
        private DateTime ExpiryDate { get; set; }
        private int Age { get; set; }


        Driver()
        {

        }
    }
}
